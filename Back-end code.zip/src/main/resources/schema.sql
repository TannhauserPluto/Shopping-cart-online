-- 确保使用正确的数据库
USE shopping_cart;

-- 如果表已存在，先删除（谨慎使用）
-- DROP TABLE IF EXISTS order_item;
-- DROP TABLE IF EXISTS `order`;
-- DROP TABLE IF EXISTS cart_item;
-- DROP TABLE IF EXISTS product;
-- DROP TABLE IF EXISTS users;